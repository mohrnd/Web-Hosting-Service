package com.authapi.webhostingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebHostingServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebHostingServiceApplication.class, args);
    }
}